# Jupyter Notebook + Python code of twitter sentiment analysis
Details and full description:
http://zablo.net/blog/post/twitter-sentiment-analysis-python-scikit-word2vec-nltk-xgboost
